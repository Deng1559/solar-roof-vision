import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';
import LoadingSpinner from './LoadingSpinner';

interface QuoteResultsProps {
  quote: any;
}

export default function QuoteResults({ quote }: QuoteResultsProps) {
  const [aiProposal, setAiProposal] = useState<string>('');

  const proposalMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/solar/ai-proposal', {
        quoteId: quote.id,
      });
      return response.json();
    },
    onSuccess: (result) => {
      setAiProposal(result.proposal);
    },
  });

  const downloadPDFMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/solar/generate-pdf`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ quoteId: quote.id }),
      });
      
      if (!response.ok) {
        throw new Error("Failed to generate quote");
      }
      
      // Open the HTML quote in a new window for printing as PDF
      const htmlContent = await response.text();
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(htmlContent);
        printWindow.document.close();
        // Add print styles and trigger print dialog
        printWindow.onload = () => {
          const style = printWindow.document.createElement('style');
          style.textContent = `
            @media print {
              body { margin: 0; }
              .no-print { display: none; }
            }
          `;
          printWindow.document.head.appendChild(style);
          setTimeout(() => printWindow.print(), 500);
        };
      }
    },
  });

  const handleGenerateProposal = () => {
    proposalMutation.mutate();
  };

  const handleDownloadPDF = () => {
    downloadPDFMutation.mutate();
  };

  return (
    <div className="bc-card">
      <div className="mb-6">
        <h3 className="text-2xl font-bold text-gray-900 mb-2">
          <i className="fas fa-calculator mr-2" style={{ color: 'var(--bc-blue)' }}></i>
          Your Solar Estimate
        </h3>
        <p className="text-gray-600">
          Professional quote for <span className="font-medium">{quote.customerAddress}</span>
        </p>
      </div>

      <div className="space-y-6">
        {/* System Details */}
        <div className="bg-gray-50 rounded-lg p-6">
          <h4 className="font-semibold text-lg mb-4 text-gray-900">System Details</h4>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Solar System Size:</span>
              <span className="font-medium">{quote.solarSizeKw} kW</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Number of Panels:</span>
              <span className="font-medium">{quote.panelCount} panels</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Battery Storage:</span>
              <span className="font-medium">{quote.batterySize} kWh</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Annual Production:</span>
              <span className="font-medium text-green-600">{quote.annualProduction.toLocaleString()} kWh</span>
            </div>
          </div>
        </div>

        {/* Pricing Breakdown */}
        <div className="border border-gray-200 rounded-lg p-6">
          <h4 className="font-semibold text-lg mb-4 text-gray-900">Investment Breakdown</h4>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Solar Panel System:</span>
              <span className="font-medium">${quote.solarCost.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Battery Storage:</span>
              <span className="font-medium">${quote.batteryCost.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Installation & Permits:</span>
              <span className="font-medium">${quote.installationCost.toLocaleString()}</span>
            </div>
            <hr className="my-3" />
            <div className="flex justify-between text-lg">
              <span className="font-medium">Subtotal:</span>
              <span className="font-bold">${quote.subtotal.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">PST (7%):</span>
              <span className="font-medium">${quote.pstAmount.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-lg border-t pt-3">
              <span className="font-semibold">Total Investment:</span>
              <span className="font-bold text-xl">${quote.totalCost.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Rebates & Incentives */}
        <div className="bg-green-50 border border-green-200 rounded-lg p-6">
          <h4 className="font-semibold text-lg mb-4 text-green-800">
            <i className="fas fa-gift mr-2"></i>
            BC Hydro Rebates
          </h4>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-green-700">Solar Panel Rebate:</span>
              <span className="font-bold text-green-600">-${quote.solarRebate.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-green-700">Battery Storage Rebate:</span>
              <span className="font-bold text-green-600">-${quote.batteryRebate.toLocaleString()}</span>
            </div>
            <hr className="border-green-300" />
            <div className="flex justify-between text-lg">
              <span className="font-semibold text-green-800">Total Rebates:</span>
              <span className="font-bold text-xl text-green-600">-${quote.totalRebates.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Final Cost */}
        <div className="text-white rounded-lg p-6" style={{ backgroundColor: 'var(--bc-blue)' }}>
          <div className="flex justify-between items-center">
            <div>
              <h4 className="text-lg font-semibold">Your Final Investment</h4>
              <p className="text-blue-100 text-sm">After all rebates and incentives</p>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold">${quote.finalCost.toLocaleString()}</div>
              <div className="text-sm text-blue-100">Save ${quote.totalRebates.toLocaleString()} in rebates!</div>
            </div>
          </div>
        </div>

        {/* ROI Information */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
          <h4 className="font-semibold text-lg mb-3 text-yellow-800">
            <i className="fas fa-chart-line mr-2"></i>
            Return on Investment
          </h4>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-yellow-700">Annual Savings:</span>
              <div className="font-bold text-lg text-yellow-600">${quote.annualSavings.toLocaleString()}</div>
            </div>
            <div>
              <span className="text-yellow-700">Payback Period:</span>
              <div className="font-bold text-lg text-yellow-600">{quote.paybackYears} years</div>
            </div>
          </div>
        </div>
      </div>

      {/* AI Proposal Generator */}
      <div className="mt-8">
        <button
          onClick={handleGenerateProposal}
          disabled={proposalMutation.isPending}
          className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-4 px-6 rounded-lg transition-all hover:shadow-lg"
        >
          <i className="fas fa-magic mr-2"></i>
          Generate AI Proposal Summary
        </button>

        {proposalMutation.isPending && (
          <LoadingSpinner message="Generating personalized proposal..." />
        )}

        {aiProposal && (
          <div className="mt-6 bg-gradient-to-br from-purple-50 to-pink-50 border border-purple-200 rounded-lg p-6">
            <h5 className="font-semibold text-lg mb-3 text-purple-800">
              <i className="fas fa-brain mr-2"></i>
              AI-Generated Proposal Summary
            </h5>
            <div className="text-gray-700 text-sm whitespace-pre-wrap leading-relaxed">
              {aiProposal}
            </div>
          </div>
        )}
      </div>

      {/* CTA Buttons */}
      <div className="mt-8 space-y-4">
        <button className="w-full text-white font-bold py-4 px-6 rounded-lg transition-all hover:shadow-lg" style={{ backgroundColor: 'var(--bc-blue)' }}>
          <i className="fas fa-calendar-check mr-2"></i>
          Schedule Site Assessment
        </button>
        <button 
          onClick={handleDownloadPDF}
          disabled={downloadPDFMutation.isPending}
          className="w-full border-2 font-semibold py-3 px-6 rounded-lg transition-all hover:bg-blue-50" 
          style={{ borderColor: 'var(--bc-blue)', color: 'var(--bc-blue)' }}
        >
          <i className="fas fa-download mr-2"></i>
          {downloadPDFMutation.isPending ? 'Generating Quote...' : 'Print PDF Quote'}
        </button>
      </div>
    </div>
  );
}
