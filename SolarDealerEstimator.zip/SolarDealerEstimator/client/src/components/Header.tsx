import { useQuery } from '@tanstack/react-query';

export default function Header() {
  const { data: tenant } = useQuery({
    queryKey: ['/api/tenant'],
  });

  return (
    <header className="bc-gradient-header text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-4">
            <div className="bg-white rounded-lg p-2">
              <i className="fas fa-solar-panel text-2xl" style={{ color: 'var(--bc-blue)' }}></i>
            </div>
            <div>
              <h1 className="text-2xl font-bold">{tenant?.businessName || 'BC Solar Solutions'}</h1>
              <p className="text-sm opacity-90">{tenant?.tagline || 'Professional Solar Estimates'}</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <button className="text-white hover:text-yellow-300 transition-colors">
              <i className="fas fa-chart-line mr-2"></i>
              <span className="hidden sm:inline">Dashboard</span>
            </button>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ backgroundColor: 'var(--bc-gold)' }}>
                <i className="fas fa-user text-sm" style={{ color: 'var(--bc-blue-dark)' }}></i>
              </div>
              <span className="hidden sm:inline">John Dealer</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
