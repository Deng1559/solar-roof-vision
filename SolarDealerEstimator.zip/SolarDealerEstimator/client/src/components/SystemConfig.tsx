import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';
import LoadingSpinner from './LoadingSpinner';

interface SystemConfigProps {
  analysisData: any;
  onQuoteGenerated: (quote: any) => void;
}

export default function SystemConfig({ analysisData, onQuoteGenerated }: SystemConfigProps) {
  const [selectedConfig, setSelectedConfig] = useState<any>(null);
  const [batterySize, setBatterySize] = useState<number>(10);

  const generateQuoteMutation = useMutation({
    mutationFn: async () => {
      if (!selectedConfig) {
        throw new Error('Please select a solar configuration');
      }

      const sizeKw = selectedConfig.panelsCount * 0.4;
      const quoteData = {
        customerAddress: analysisData.address,
        latitude: analysisData.latitude,
        longitude: analysisData.longitude,
        solarSizeKw: sizeKw,
        panelCount: selectedConfig.panelsCount,
        batterySize: batterySize,
        annualProduction: selectedConfig.yearlyEnergyDcKwh,
        roofImageUrl: analysisData.roofImageUrl,
        solarPotentialConfigs: analysisData.solarPotential?.solarPanelConfigs,
      };

      const response = await apiRequest('POST', '/api/solar/quote', quoteData);
      return response.json();
    },
    onSuccess: (quote) => {
      onQuoteGenerated(quote);
    },
  });

  const handleConfigSelect = (config: any) => {
    setSelectedConfig(config);
  };

  const handleGenerateQuote = () => {
    generateQuoteMutation.mutate();
  };

  return (
    <div className="mt-8">
      <h4 className="text-xl font-bold text-gray-900 mb-4">
        <i className="fas fa-cogs mr-2" style={{ color: 'var(--bc-blue)' }}></i>
        2. Configure Your System
      </h4>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Solar Panel Configuration
          </label>
          <div className="space-y-2">
            {analysisData.solarPotential?.solarPanelConfigs?.slice(0, 4).map((config: any, index: number) => {
              const sizeKw = (config.panelsCount * 0.4).toFixed(1);
              const cost = (parseFloat(sizeKw) * 3000).toLocaleString();
              const isSelected = selectedConfig?.panelsCount === config.panelsCount;
              
              return (
                <button
                  key={index}
                  onClick={() => handleConfigSelect(config)}
                  className={`w-full text-left p-4 rounded-lg border-2 transition-all ${
                    isSelected 
                      ? 'border-bc-blue bg-blue-50' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  style={{ 
                    borderColor: isSelected ? 'var(--bc-blue)' : undefined,
                    backgroundColor: isSelected ? 'rgba(0, 90, 135, 0.05)' : undefined,
                  }}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="font-medium">
                        {sizeKw}kW System ({config.panelsCount} panels)
                      </div>
                      <div className="text-sm text-gray-600">
                        Annual Production: {Math.round(config.yearlyEnergyDcKwh).toLocaleString()} kWh
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold">${cost}</div>
                      <div className="text-xs text-gray-500">before rebates</div>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Battery Storage (kWh)
          </label>
          <input
            type="number"
            min="0"
            max="40"
            value={batterySize}
            onChange={(e) => setBatterySize(parseInt(e.target.value) || 0)}
            className="bc-input"
          />
          <p className="text-xs text-gray-500 mt-1">
            Minimum 5 kWh required for BC Hydro battery rebate
          </p>
        </div>

        <button
          onClick={handleGenerateQuote}
          disabled={!selectedConfig || generateQuoteMutation.isPending}
          className="w-full bc-button-primary py-3 px-6 rounded-lg"
        >
          <i className="fas fa-file-invoice-dollar mr-2"></i>
          Generate Quote
        </button>

        {generateQuoteMutation.isPending && (
          <LoadingSpinner message="Generating your personalized quote..." />
        )}

        {generateQuoteMutation.error && (
          <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-600 text-sm">
              <i className="fas fa-exclamation-triangle mr-2"></i>
              Failed to generate quote. Please try again.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
