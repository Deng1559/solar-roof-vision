interface LoadingSpinnerProps {
  message?: string;
}

export default function LoadingSpinner({ message = "Loading..." }: LoadingSpinnerProps) {
  return (
    <div className="flex items-center justify-center py-8">
      <div className="inline-flex items-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-bc-blue mr-3" style={{ borderColor: 'var(--bc-blue)' }}></div>
        <span className="text-gray-600">{message}</span>
      </div>
    </div>
  );
}
