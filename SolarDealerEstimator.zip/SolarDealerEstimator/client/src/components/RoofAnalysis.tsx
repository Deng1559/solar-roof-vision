import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '../lib/queryClient';
import LoadingSpinner from './LoadingSpinner';

interface RoofAnalysisProps {
  data: any;
  onConfigReady: () => void;
}

export default function RoofAnalysis({ data, onConfigReady }: RoofAnalysisProps) {
  const [aiAnalysis, setAiAnalysis] = useState<string>('');

  const aiAnalysisMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/solar/ai-analysis', {
        roofImageUrl: data.roofImageUrl,
        solarConfigs: data.solarPotential?.solarPanelConfigs || [],
      });
      return response.json();
    },
    onSuccess: (result) => {
      setAiAnalysis(result.analysis);
    },
  });

  const handleGetAIAnalysis = () => {
    aiAnalysisMutation.mutate();
  };

  const handleConfigureSystem = () => {
    onConfigReady();
  };

  return (
    <div className="mt-6">
      <h4 className="font-semibold text-lg mb-3">Your Roof Analysis</h4>
      <div className="relative rounded-lg overflow-hidden shadow-lg">
        <img
          src={data.roofImageUrl}
          alt="Satellite view of residential roof"
          className="w-full h-64 object-cover"
        />
        <div className="absolute top-4 right-4 bg-white bg-opacity-90 rounded-lg px-3 py-2">
          <span className="text-sm font-medium text-green-600">
            <i className="fas fa-check-circle mr-1"></i>
            Excellent Solar Potential
          </span>
        </div>
      </div>

      <button
        onClick={handleGetAIAnalysis}
        disabled={aiAnalysisMutation.isPending}
        className="w-full mt-4 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition-all"
      >
        <i className="fas fa-brain mr-2"></i>
        Get AI Roof Analysis
      </button>

      {aiAnalysisMutation.isPending && (
        <LoadingSpinner message="Analyzing roof potential..." />
      )}

      {aiAnalysis && (
        <div className="mt-4 bg-gradient-to-br from-purple-50 to-pink-50 border border-purple-200 rounded-lg p-6">
          <h5 className="font-semibold text-lg mb-3 text-purple-800">
            <i className="fas fa-brain mr-2"></i>
            AI Roof Analysis
          </h5>
          <div className="text-gray-700 text-sm whitespace-pre-wrap leading-relaxed">
            {aiAnalysis}
          </div>
        </div>
      )}

      {data.solarPotential && (
        <div className="mt-6">
          <h4 className="font-semibold text-lg mb-3 text-gray-900">Available Solar Configurations</h4>
          <div className="grid gap-3">
            {data.solarPotential.solarPanelConfigs?.slice(0, 4).map((config: any, index: number) => {
              const sizeKw = (config.panelsCount * 0.4).toFixed(1);
              const cost = (parseFloat(sizeKw) * 3000).toLocaleString();
              return (
                <div key={index} className="bg-gray-50 rounded-lg p-4 border">
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="font-medium">
                        {sizeKw}kW System ({config.panelsCount} panels)
                      </span>
                      <div className="text-sm text-gray-600">
                        {Math.round(config.yearlyEnergyDcKwh).toLocaleString()} kWh/year
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-lg">${cost}</div>
                      <div className="text-xs text-gray-500">before rebates</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          
          <button
            onClick={handleConfigureSystem}
            className="w-full mt-6 bc-button-primary py-3 px-6 rounded-lg"
          >
            <i className="fas fa-cogs mr-2"></i>
            Configure Your System
          </button>
        </div>
      )}
    </div>
  );
}
