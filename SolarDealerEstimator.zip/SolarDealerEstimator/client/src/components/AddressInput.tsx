import { useRef, useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useGooglePlaces } from '../hooks/useGoogleMaps';
import { apiRequest } from '../lib/queryClient';
import LoadingSpinner from './LoadingSpinner';

interface AddressInputProps {
  onAnalysisComplete: (data: any) => void;
}

export default function AddressInput({ onAnalysisComplete }: AddressInputProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [selectedPlace, setSelectedPlace] = useState<any>(null);

  const analyzeMutation = useMutation({
    mutationFn: async (placeData: any) => {
      const response = await apiRequest('POST', '/api/solar/analyze', placeData);
      return response.json();
    },
    onSuccess: (data) => {
      onAnalysisComplete(data);
    },
  });

  const { isLoaded } = useGooglePlaces(inputRef, (place) => {
    setSelectedPlace(place);
  });

  const handleAnalyze = () => {
    if (!selectedPlace) {
      alert('Please select a valid BC address from the dropdown.');
      return;
    }
    analyzeMutation.mutate(selectedPlace);
  };

  return (
    <div className="bc-card">
      <div className="mb-6">
        <h3 className="text-2xl font-bold text-gray-900 mb-2">
          <i className="fas fa-map-marker-alt mr-2" style={{ color: 'var(--bc-blue)' }}></i>
          1. Enter Your Address
        </h3>
        <p className="text-gray-600">Start by entering your BC residential address</p>
      </div>

      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Your Home Address
        </label>
        <div className="relative">
          <input
            ref={inputRef}
            type="text"
            placeholder={isLoaded ? "Enter your BC residential address" : "Loading Google Maps..."}
            disabled={!isLoaded}
            className="bc-input"
          />
          <i className="fas fa-search absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
        </div>
      </div>

      <button
        onClick={handleAnalyze}
        disabled={!selectedPlace || analyzeMutation.isPending}
        className="w-full bc-button-primary py-3 px-6 rounded-lg"
      >
        <i className="fas fa-satellite mr-2"></i>
        Analyze Solar Potential
      </button>

      {analyzeMutation.isPending && (
        <LoadingSpinner message="Analyzing your roof with AI..." />
      )}

      {analyzeMutation.error && (
        <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-600 text-sm">
            <i className="fas fa-exclamation-triangle mr-2"></i>
            Failed to analyze solar potential. Please try again.
          </p>
        </div>
      )}
    </div>
  );
}
