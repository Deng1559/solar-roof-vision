import { useState } from 'react';
import Header from '../components/Header';
import AddressInput from '../components/AddressInput';
import RoofAnalysis from '../components/RoofAnalysis';
import SystemConfig from '../components/SystemConfig';
import QuoteResults from '../components/QuoteResults';

export default function Home() {
  const [analysisData, setAnalysisData] = useState<any>(null);
  const [showConfig, setShowConfig] = useState(false);
  const [quote, setQuote] = useState<any>(null);

  const handleAnalysisComplete = (data: any) => {
    setAnalysisData(data);
    setShowConfig(false);
    setQuote(null);
  };

  const handleConfigReady = () => {
    setShowConfig(true);
  };

  const handleQuoteGenerated = (newQuote: any) => {
    setQuote(newQuote);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <div className="text-center mb-8">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Get Your Solar Estimate</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Discover your home's solar potential with our advanced AI-powered analysis. 
              Get accurate estimates for solar panels, battery storage, and BC Hydro rebates.
            </p>
          </div>
          
          {/* Feature Grid */}
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <div className="text-center p-6 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg">
              <i className="fas fa-satellite text-3xl mb-4" style={{ color: 'var(--bc-blue)' }}></i>
              <h3 className="font-semibold text-lg mb-2">Satellite Analysis</h3>
              <p className="text-gray-600">AI-powered roof analysis using Google Solar API</p>
            </div>
            <div className="text-center p-6 bg-gradient-to-br from-yellow-50 to-amber-50 rounded-lg">
              <i className="fas fa-calculator text-3xl mb-4" style={{ color: 'var(--bc-gold)' }}></i>
              <h3 className="font-semibold text-lg mb-2">Instant Quotes</h3>
              <p className="text-gray-600">Real-time pricing with BC Hydro rebate calculations</p>
            </div>
            <div className="text-center p-6 bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg">
              <i className="fas fa-leaf text-3xl text-green-600 mb-4"></i>
              <h3 className="font-semibold text-lg mb-2">Clean Energy</h3>
              <p className="text-gray-600">Reduce your carbon footprint and energy bills</p>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left Column - Input & Configuration */}
          <div className="space-y-8">
            <AddressInput onAnalysisComplete={handleAnalysisComplete} />
            
            {analysisData && (
              <div className="bc-card">
                <RoofAnalysis 
                  data={analysisData} 
                  onConfigReady={handleConfigReady}
                />
                
                {showConfig && (
                  <SystemConfig 
                    analysisData={analysisData}
                    onQuoteGenerated={handleQuoteGenerated}
                  />
                )}
              </div>
            )}
          </div>

          {/* Right Column - Results */}
          <div>
            {quote ? (
              <QuoteResults quote={quote} />
            ) : (
              <div className="bc-card">
                <div className="text-center py-12">
                  <i className="fas fa-calculator text-6xl text-gray-300 mb-4"></i>
                  <h3 className="text-xl font-semibold text-gray-600 mb-2">Ready for Your Quote</h3>
                  <p className="text-gray-500">
                    Enter your address and configure your system to see your personalized solar estimate.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Additional Info */}
        <div className="mt-12 grid md:grid-cols-3 gap-8">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <img
              src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
              alt="Modern home with solar panels"
              className="w-full h-48 object-cover rounded-lg mb-4"
            />
            <h4 className="font-bold text-lg mb-2">Why Go Solar in BC?</h4>
            <p className="text-gray-600 text-sm">
              BC offers some of Canada's best solar incentives, with up to $10,000 in rebates available through BC Hydro's CleanBC programs.
            </p>
          </div>
          
          <div className="bg-white rounded-xl shadow-lg p-6">
            <img
              src="https://images.unsplash.com/photo-1466611653911-95081537e5b7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
              alt="Clean energy landscape"
              className="w-full h-48 object-cover rounded-lg mb-4"
            />
            <h4 className="font-bold text-lg mb-2">Environmental Impact</h4>
            <p className="text-gray-600 text-sm">
              Your solar system will offset tons of CO2 emissions annually, equivalent to planting hundreds of trees each year.
            </p>
          </div>
          
          <div className="bg-white rounded-xl shadow-lg p-6">
            <img
              src="https://images.unsplash.com/photo-1509391366360-2e959784a276?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
              alt="Professional solar installation"
              className="w-full h-48 object-cover rounded-lg mb-4"
            />
            <h4 className="font-bold text-lg mb-2">Professional Installation</h4>
            <p className="text-gray-600 text-sm">
              Our certified installers ensure your system meets all BC electrical codes and warranty requirements for maximum performance.
            </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h5 className="font-bold text-lg mb-4">BC Solar Solutions</h5>
              <p className="text-gray-400 text-sm">
                Professional solar installations across British Columbia. Certified installers, premium equipment, comprehensive warranties.
              </p>
            </div>
            <div>
              <h6 className="font-semibold mb-4">Contact</h6>
              <div className="space-y-2 text-sm text-gray-400">
                <div>
                  <i className="fas fa-phone mr-2"></i>
                  (604) 555-0123
                </div>
                <div>
                  <i className="fas fa-envelope mr-2"></i>
                  info@bcsolarsolutions.com
                </div>
                <div>
                  <i className="fas fa-map-marker-alt mr-2"></i>
                  Vancouver, BC
                </div>
              </div>
            </div>
            <div>
              <h6 className="font-semibold mb-4">Services</h6>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>Residential Solar</li>
                <li>Battery Storage</li>
                <li>System Monitoring</li>
                <li>Maintenance</li>
              </ul>
            </div>
            <div>
              <h6 className="font-semibold mb-4">Certifications</h6>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>CSA Certified</li>
                <li>BC Licensed Electricians</li>
                <li>NABCEP Certified</li>
                <li>WorkSafeBC Compliant</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2024 BC Solar Solutions. All rights reserved. | Powered by SolarBuilder</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
