export const SOLAR_CONFIG = {
  residential: {
    costPerKwSolar: 3000,
    costPerKwhBattery: 900,
    solarProductCostRatio: 0.70,
    batteryProductCostRatio: 0.80,
    bcHydroSolarRebatePerKw: 1000,
    bcHydroSolarRebateMax: 5000,
    bcHydroBatteryRebatePerKwh: 500,
    bcHydroBatteryRebateMax: 5000,
    minBatteryKwh: 5,
  },
  pstRate: 0.07,
  dcToAcDerate: 0.85,
  electricityRatePerKwh: 0.12,
};

export const GOOGLE_MAPS_CONFIG = {
  componentRestrictions: { country: "ca" },
  fields: ["formatted_address", "geometry"],
};
