# BC Solar Solutions - Solar Quote Generator v1.0

## Overview

BC Solar Solutions is a **multi-tenant lead generation platform** that hosts multiple solar installation companies across British Columbia. The platform provides professional solar quotes by analyzing satellite imagery, calculating costs, and generating AI-powered proposals for residential solar installations, allowing solar dealers to capture and convert leads efficiently.

## System Architecture

### Full-Stack Architecture
- **Frontend**: React with TypeScript and Vite
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **UI Framework**: Tailwind CSS with shadcn/ui components
- **AI Integration**: Google Gemini API for roof analysis and proposal generation
- **External APIs**: Google Solar API for building insights and satellite imagery

### Multi-Tenant Lead Generation Platform
The platform is designed as a **host service for multiple solar companies** to generate leads. Each tenant (solar dealer) gets:
- **Custom branding** and business information
- **Lead capture** through professional quote generation
- **Isolated quote data** for their customers
- **Professional PDF quotes** with their company details
- **Real-time satellite analysis** to impress potential customers

## Key Components

### Frontend Components
- **AddressInput**: Google Places API integration for address geocoding
- **RoofAnalysis**: Satellite imagery display with AI-powered roof assessment
- **SystemConfig**: Solar panel configuration selection interface
- **QuoteResults**: Comprehensive quote display with financial calculations
- **Header**: Tenant-aware branding and navigation

### Backend Services
- **Solar Service**: Integration with Google Solar API for building insights
- **Gemini Service**: AI-powered roof analysis and proposal generation
- **Storage Layer**: Abstracted data layer supporting both in-memory and PostgreSQL storage

### Database Schema
- **Tenants**: Multi-tenant business information and branding
- **Solar Quotes**: Comprehensive quote data including system specifications, costs, and AI analysis

## Data Flow

1. **Address Input**: User enters BC residential address
2. **Geocoding**: Google Places API converts address to coordinates
3. **Solar Analysis**: Google Solar API provides building insights and satellite imagery
4. **AI Assessment**: Gemini API analyzes roof conditions and solar potential
5. **System Configuration**: User selects solar panel and battery configurations
6. **Quote Generation**: Backend calculates costs, rebates, and savings
7. **AI Proposal**: Gemini generates professional proposal summary
8. **Quote Storage**: Complete quote data stored in PostgreSQL

## External Dependencies

### Google APIs
- **Google Solar API**: Building insights and satellite imagery
- **Google Places API**: Address geocoding and validation
- **Google Gemini API**: AI-powered roof analysis and proposal generation

### Database & Storage
- **PostgreSQL**: Primary data storage via Neon serverless
- **Drizzle ORM**: Type-safe database queries and migrations

### UI & Styling
- **Tailwind CSS**: Utility-first styling framework
- **shadcn/ui**: Accessible React component library
- **Radix UI**: Primitive components for complex interactions

## Deployment Strategy

### Development Environment
- **Replit**: Cloud-based development with integrated PostgreSQL
- **Vite**: Fast development server with HMR
- **TypeScript**: Type safety across frontend and backend

### Production Deployment
- **Autoscale**: Replit deployment target for automatic scaling
- **Build Process**: Vite builds frontend, esbuild bundles backend
- **Environment Variables**: Secure API key management

### Configuration Files
- **Drizzle Config**: Database schema management and migrations
- **Vite Config**: Frontend build configuration with path aliases
- **TypeScript Config**: Shared type definitions across client/server

## API Setup Requirements

### Google Solar API (Optional - Enhanced Features)
To enable real satellite imagery and precise solar calculations:
1. Visit [Google Cloud Console](https://console.cloud.google.com/)
2. Enable the Solar API for your project
3. Create API credentials
4. Add the key as `GOOGLE_SOLAR_API_KEY` environment variable

### Google Maps Static API (For Real Satellite Images)
To display actual roof satellite imagery instead of placeholder images:
1. Visit [Google Cloud Console](https://console.cloud.google.com/)
2. Select your project or create a new one
3. Navigate to "APIs & Services" > "Library"
4. Search for "Maps Static API" and click "Enable"
5. Go to "APIs & Services" > "Credentials"
6. Create a new API key or use existing one
7. Restrict the key to "Maps Static API" for security
8. Add the key as `GOOGLE_MAPS_API_KEY` environment variable

**Important**: The API key must have Maps Static API specifically enabled, not just Maps JavaScript API.

### Version 1.0 Status - PRODUCTION READY ✅
- **Lead generation platform** ready to host multiple solar companies
- **Complete end-to-end workflow** from address input to PDF quote delivery
- **Real satellite roof imagery** using Esri World Imagery service for impressive customer presentations
- **AI-powered analysis** with Gemini API to demonstrate expertise and professionalism
- **Professional PDF quotes** with tenant branding and complete financial breakdowns
- **Accurate BC calculations** including BC Hydro rebates up to $10,000
- **Multi-tenant architecture** supporting unlimited solar dealers on one platform
- **Lead capture system** - each quote becomes a qualified lead for the solar company
- **Tested and verified** - All core features working in production

## Troubleshooting

### API Rate Limits
If you see quota exceeded errors:
- Gemini free tier: 15 requests per minute
- Wait a few minutes before retrying AI features
- Consider upgrading to paid tier for higher limits

### Google APIs Not Working
- Check if APIs are enabled in Google Cloud Console
- Verify API keys have proper permissions
- Ensure billing is set up for paid APIs

## Changelog

### Version 1.0 - June 24, 2025 ✅ PRODUCTION READY
- **Complete BC Solar Solutions application deployed**
- **Real satellite imagery** from Esri World Imagery service for accurate roof views
- **AI-powered roof analysis** with Gemini API and robust fallback system
- **Professional PDF quote generation** with BC Solar branding and BC Hydro rebate calculations
- **Multi-tenant architecture** supporting multiple solar dealers
- **Complete workflow**: Address → Satellite → AI Analysis → Quote → PDF
- **Financial calculations**: Accurate BC pricing with up to $10,000 BC Hydro rebates
- **Production tested**: All core functionality verified and working

## Business Model

**Lead Generation Platform for Solar Companies**
- Platform hosts multiple solar installation companies
- Each company gets their own tenant space with custom branding
- Professional quotes capture leads and demonstrate expertise
- Satellite imagery and AI analysis impress potential customers
- Companies pay to be hosted on the platform and receive qualified leads

## User Preferences

Preferred communication style: Simple, everyday language.