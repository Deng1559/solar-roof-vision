import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSolarQuoteSchema } from "@shared/schema";
import { getSolarBuildingInsights, calculateQuote } from "./services/solar";
import { analyzeSiteRoof, generateProposalSummary } from "./services/gemini";
import { generateQuotePDF } from "./services/pdf";

async function generateSatelliteImage(latitude: number, longitude: number): Promise<string> {
  // Use USGS/NASA satellite imagery service that provides high-resolution imagery
  const zoom = 18;
  const tileX = Math.floor((longitude + 180) / 360 * Math.pow(2, zoom));
  const tileY = Math.floor((1 - Math.log(Math.tan(latitude * Math.PI / 180) + 1 / Math.cos(latitude * Math.PI / 180)) / Math.PI) / 2 * Math.pow(2, zoom));
  
  // Use Esri World Imagery which provides real satellite data
  const satelliteUrl = `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${zoom}/${tileY}/${tileX}`;
  
  console.log(`Generated real satellite tile for coordinates: ${latitude}, ${longitude} - Tile: ${zoom}/${tileY}/${tileX}`);
  return satelliteUrl;
}

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get tenant info (for multi-tenant support)
  app.get("/api/tenant", async (req, res) => {
    try {
      const host = req.get('host') || '';
      const tenant = await storage.getTenantByDomain(host);
      if (!tenant) {
        return res.status(404).json({ error: "Tenant not found" });
      }
      res.json(tenant);
    } catch (error) {
      res.status(500).json({ error: "Failed to get tenant info" });
    }
  });

  // Geocode address and get solar data
  app.post("/api/solar/analyze", async (req, res) => {
    try {
      const { address, latitude, longitude } = req.body;
      
      if (!latitude || !longitude) {
        return res.status(400).json({ error: "Latitude and longitude required" });
      }

      const buildingInsights = await getSolarBuildingInsights(latitude, longitude);
      
      // Generate real satellite image using Google Maps Static API
      const roofImageUrl = await generateSatelliteImage(latitude, longitude);

      res.json({
        ...buildingInsights,
        roofImageUrl,
        address,
        latitude,
        longitude,
      });
    } catch (error) {
      console.error("Solar analysis error:", error);
      res.status(500).json({ error: "Failed to analyze solar potential" });
    }
  });

  // Generate AI roof analysis
  app.post("/api/solar/ai-analysis", async (req, res) => {
    try {
      const { roofImageUrl, solarConfigs } = req.body;
      
      if (!roofImageUrl || !solarConfigs) {
        return res.status(400).json({ error: "Roof image URL and solar configs required" });
      }

      const analysis = await analyzeSiteRoof(roofImageUrl, solarConfigs);
      res.json({ analysis });
    } catch (error) {
      console.error("AI analysis error:", error);
      res.status(500).json({ error: "Failed to generate AI analysis" });
    }
  });

  // Generate quote
  app.post("/api/solar/quote", async (req, res) => {
    try {
      const quoteData = req.body;
      
      // Calculate quote details
      const calculatedQuote = calculateQuote(
        quoteData.solarSizeKw,
        quoteData.panelCount,
        quoteData.batterySize,
        quoteData.annualProduction
      );

      // Create complete quote object
      const completeQuote = {
        tenantId: 1, // Default tenant for now
        customerAddress: quoteData.customerAddress,
        latitude: quoteData.latitude,
        longitude: quoteData.longitude,
        roofImageUrl: quoteData.roofImageUrl,
        solarPotentialConfigs: quoteData.solarPotentialConfigs,
        aiAnalysis: quoteData.aiAnalysis,
        ...calculatedQuote,
      };

      // Save quote to storage
      const savedQuote = await storage.createSolarQuote(completeQuote);
      
      res.json(savedQuote);
    } catch (error) {
      console.error("Quote generation error:", error);
      res.status(500).json({ error: "Failed to generate quote" });
    }
  });

  // Generate AI proposal
  app.post("/api/solar/ai-proposal", async (req, res) => {
    try {
      const { quoteId } = req.body;
      
      if (!quoteId) {
        return res.status(400).json({ error: "Quote ID required" });
      }

      const quote = await storage.getSolarQuote(quoteId);
      if (!quote) {
        return res.status(404).json({ error: "Quote not found" });
      }

      const proposal = await generateProposalSummary(quote);
      
      // Update quote with AI proposal
      const updatedQuote = await storage.updateSolarQuote(quoteId, { aiProposal: proposal });
      
      res.json({ proposal });
    } catch (error) {
      console.error("AI proposal error:", error);
      res.status(500).json({ error: "Failed to generate AI proposal" });
    }
  });

  // Generate PDF quote
  app.post("/api/solar/generate-pdf", async (req, res) => {
    try {
      const { quoteId } = req.body;
      
      if (!quoteId) {
        return res.status(400).json({ error: "Quote ID required" });
      }

      const quote = await storage.getSolarQuote(quoteId);
      if (!quote) {
        return res.status(404).json({ error: "Quote not found" });
      }

      // Generate PDF content
      const pdfBuffer = await generateQuotePDF(quote, quote.aiProposal || "Professional solar analysis pending.");
      
      // Set headers for HTML quote that can be printed as PDF
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.setHeader('Content-Disposition', `inline; filename="BC-Solar-Quote-${quote.id}.html"`);
      res.setHeader('Content-Length', pdfBuffer.length);
      
      res.end(pdfBuffer);
    } catch (error) {
      console.error("PDF generation error:", error);
      res.status(500).json({ error: "Failed to generate PDF quote" });
    }
  });

  // Get quote by ID
  app.get("/api/solar/quote/:id", async (req, res) => {
    try {
      const quoteId = parseInt(req.params.id);
      const quote = await storage.getSolarQuote(quoteId);
      
      if (!quote) {
        return res.status(404).json({ error: "Quote not found" });
      }
      
      res.json(quote);
    } catch (error) {
      res.status(500).json({ error: "Failed to get quote" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
