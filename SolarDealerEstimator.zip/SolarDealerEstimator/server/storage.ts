import { tenants, solarQuotes, type Tenant, type InsertTenant, type SolarQuote, type InsertSolarQuote } from "@shared/schema";

export interface IStorage {
  // Tenant methods
  getTenant(id: number): Promise<Tenant | undefined>;
  getTenantByDomain(domain: string): Promise<Tenant | undefined>;
  createTenant(tenant: InsertTenant): Promise<Tenant>;
  getAllTenants(): Promise<Tenant[]>;
  
  // Solar quote methods  
  getSolarQuote(id: number): Promise<SolarQuote | undefined>;
  createSolarQuote(quote: InsertSolarQuote): Promise<SolarQuote>;
  getSolarQuotesByTenant(tenantId: number): Promise<SolarQuote[]>;
  updateSolarQuote(id: number, updates: Partial<SolarQuote>): Promise<SolarQuote | undefined>;
}

export class MemStorage implements IStorage {
  private tenants: Map<number, Tenant>;
  private solarQuotes: Map<number, SolarQuote>;
  private currentTenantId: number;
  private currentQuoteId: number;

  constructor() {
    this.tenants = new Map();
    this.solarQuotes = new Map();
    this.currentTenantId = 1;
    this.currentQuoteId = 1;
    
    // Initialize with default tenant
    this.createTenant({
      businessName: "BC Solar Solutions",
      tagline: "Professional Solar Estimates",
      phone: "(604) 555-0123",
      email: "info@bcsolarsolutions.com",
      address: "Vancouver, BC",
      description: "Professional solar installations across British Columbia. Certified installers, premium equipment, comprehensive warranties.",
      primaryColor: "#005a87",
      secondaryColor: "#fdb913",
      isActive: true,
    });
  }

  async getTenant(id: number): Promise<Tenant | undefined> {
    return this.tenants.get(id);
  }

  async getTenantByDomain(domain: string): Promise<Tenant | undefined> {
    // For now, return default tenant - in production this would map domains to tenants
    return Array.from(this.tenants.values())[0];
  }

  async createTenant(insertTenant: InsertTenant): Promise<Tenant> {
    const id = this.currentTenantId++;
    const tenant: Tenant = { 
      ...insertTenant, 
      id,
      address: insertTenant.address || null,
      tagline: insertTenant.tagline || null,
      phone: insertTenant.phone || null,
      email: insertTenant.email || null,
      description: insertTenant.description || null,
      logoUrl: insertTenant.logoUrl || null,
      primaryColor: insertTenant.primaryColor || "#005a87",
      secondaryColor: insertTenant.secondaryColor || "#fdb913",
      isActive: insertTenant.isActive !== undefined ? insertTenant.isActive : true,
    };
    this.tenants.set(id, tenant);
    return tenant;
  }

  async getAllTenants(): Promise<Tenant[]> {
    return Array.from(this.tenants.values());
  }

  async getSolarQuote(id: number): Promise<SolarQuote | undefined> {
    return this.solarQuotes.get(id);
  }

  async createSolarQuote(insertQuote: InsertSolarQuote): Promise<SolarQuote> {
    const id = this.currentQuoteId++;
    const quote: SolarQuote = { 
      ...insertQuote, 
      id,
      tenantId: insertQuote.tenantId || null,
      batterySize: insertQuote.batterySize || null,
      batteryCost: insertQuote.batteryCost || null,
      batteryRebate: insertQuote.batteryRebate || null,
      roofImageUrl: insertQuote.roofImageUrl || null,
      solarPotentialConfigs: insertQuote.solarPotentialConfigs || null,
      aiAnalysis: insertQuote.aiAnalysis || null,
      aiProposal: insertQuote.aiProposal || null,
    };
    this.solarQuotes.set(id, quote);
    return quote;
  }

  async getSolarQuotesByTenant(tenantId: number): Promise<SolarQuote[]> {
    return Array.from(this.solarQuotes.values()).filter(
      (quote) => quote.tenantId === tenantId,
    );
  }

  async updateSolarQuote(id: number, updates: Partial<SolarQuote>): Promise<SolarQuote | undefined> {
    const quote = this.solarQuotes.get(id);
    if (!quote) return undefined;
    
    const updatedQuote = { ...quote, ...updates };
    this.solarQuotes.set(id, updatedQuote);
    return updatedQuote;
  }
}

export const storage = new MemStorage();
