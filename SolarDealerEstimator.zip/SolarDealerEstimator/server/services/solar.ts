export interface SolarConfig {
  panelsCount: number;
  yearlyEnergyDcKwh: number;
}

export interface SolarPotential {
  maxArrayPanelsCount: number;
  solarPanelConfigs: SolarConfig[];
  roofSegmentStats: any[];
}

export interface BuildingInsights {
  solarPotential: SolarPotential;
  satelliteImage?: {
    uri: string;
  };
}

const SOLAR_API_KEY = process.env.GEMINI_API_KEY || "";

export async function getSolarBuildingInsights(latitude: number, longitude: number): Promise<BuildingInsights> {
  // Note: Google Solar API requires separate enablement. Using realistic BC solar data for now.
  console.log(`Generating solar insights for coordinates: ${latitude}, ${longitude}`);
  
  // Calculate realistic configurations based on BC climate and typical roof sizes
  const baseAnnualSunlight = 1300; // kWh/m²/year for BC
  const panelWattage = 400; // Modern panel wattage
  const roofSizeMultiplier = Math.random() * 0.3 + 0.8; // 80-110% roof efficiency
  
  const configs = [
    { panelsCount: 12, yearlyEnergyDcKwh: Math.round(12 * panelWattage * baseAnnualSunlight / 1000 * roofSizeMultiplier) },
    { panelsCount: 18, yearlyEnergyDcKwh: Math.round(18 * panelWattage * baseAnnualSunlight / 1000 * roofSizeMultiplier) },
    { panelsCount: 24, yearlyEnergyDcKwh: Math.round(24 * panelWattage * baseAnnualSunlight / 1000 * roofSizeMultiplier) },
    { panelsCount: 30, yearlyEnergyDcKwh: Math.round(30 * panelWattage * baseAnnualSunlight / 1000 * roofSizeMultiplier) },
    { panelsCount: 36, yearlyEnergyDcKwh: Math.round(36 * panelWattage * baseAnnualSunlight / 1000 * roofSizeMultiplier) },
  ];

  return {
    solarPotential: {
      maxArrayPanelsCount: 36,
      solarPanelConfigs: configs,
      roofSegmentStats: [],
    },
  };
}

export function calculateQuote(
  solarSizeKw: number,
  panelCount: number,
  batterySize: number,
  annualProduction: number,
): any {
  const config = {
    costPerKwSolar: 3000,
    costPerKwhBattery: 900,
    solarProductCostRatio: 0.70,
    batteryProductCostRatio: 0.80,
    bcHydroSolarRebatePerKw: 1000,
    bcHydroSolarRebateMax: 5000,
    bcHydroBatteryRebatePerKwh: 500,
    bcHydroBatteryRebateMax: 5000,
    minBatteryKwh: 5,
    pstRate: 0.07,
    dcToAcDerate: 0.85,
    electricityRatePerKwh: 0.12,
  };

  // Calculate costs
  const solarCost = solarSizeKw * config.costPerKwSolar;
  const batteryCost = batterySize * config.costPerKwhBattery;
  const installationCost = (solarCost + batteryCost) * 0.10; // 10% installation
  const subtotal = solarCost + batteryCost + installationCost;
  const pstAmount = subtotal * config.pstRate;
  const totalCost = subtotal + pstAmount;

  // Calculate rebates
  const solarRebate = Math.min(solarSizeKw * config.bcHydroSolarRebatePerKw, config.bcHydroSolarRebateMax);
  const batteryRebate = batterySize >= config.minBatteryKwh 
    ? Math.min(batterySize * config.bcHydroBatteryRebatePerKwh, config.bcHydroBatteryRebateMax)
    : 0;
  const totalRebates = solarRebate + batteryRebate;
  const finalCost = totalCost - totalRebates;

  // Calculate savings and ROI
  const annualAcProduction = annualProduction * config.dcToAcDerate;
  const annualSavings = annualAcProduction * config.electricityRatePerKwh;
  const paybackYears = Math.round(finalCost / annualSavings);

  return {
    solarSizeKw,
    panelCount,
    batterySize,
    solarCost,
    batteryCost,
    installationCost,
    subtotal,
    pstAmount,
    totalCost,
    solarRebate,
    batteryRebate,
    totalRebates,
    finalCost,
    annualProduction,
    annualSavings: Math.round(annualSavings),
    paybackYears,
  };
}
