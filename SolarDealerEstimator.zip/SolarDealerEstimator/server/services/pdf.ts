export async function generateQuotePDF(quoteData: any, proposal: string): Promise<Buffer> {
  console.log('Generating PDF for quote:', quoteData.id);
  
  const htmlContent = generateHTMLQuote(quoteData, proposal);
  return Buffer.from(htmlContent, 'utf-8');
}

function generateHTMLQuote(quoteData: any, proposal: string): string {
  return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>BC Solar Solutions - Quote</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; color: #333; }
        .header { color: #0066cc; border-bottom: 2px solid #0066cc; padding-bottom: 10px; margin-bottom: 20px; }
        .header h1 { margin: 0; font-size: 28px; }
        .header p { margin: 5px 0; color: #666; }
        .section { margin: 20px 0; }
        .section h2 { color: #0066cc; border-bottom: 1px solid #0066cc; padding-bottom: 5px; }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .quote-item { margin: 8px 0; }
        .quote-item strong { color: #0066cc; }
        .financial { background: #f8f9fa; padding: 15px; border-radius: 8px; }
        .proposal { background: #f0f8ff; padding: 15px; border-radius: 8px; margin-top: 20px; }
        .footer { margin-top: 40px; text-align: center; color: #666; font-size: 12px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>BC Solar Solutions</h1>
        <p>Professional Solar Installation & Energy Solutions</p>
        <p>Quote Date: ${new Date().toLocaleDateString()}</p>
    </div>

    <div class="section">
        <h2>Customer Information</h2>
        <div class="quote-item"><strong>Address:</strong> ${quoteData.customerAddress}</div>
        <div class="quote-item"><strong>Quote ID:</strong> ${quoteData.id}</div>
    </div>

    <div class="grid">
        <div class="section">
            <h2>System Configuration</h2>
            <div class="quote-item"><strong>Solar Panel Count:</strong> ${quoteData.panelCount} panels</div>
            <div class="quote-item"><strong>System Size:</strong> ${quoteData.solarSizeKw} kW</div>
            <div class="quote-item"><strong>Battery Storage:</strong> ${quoteData.batterySize || 0} kWh</div>
            <div class="quote-item"><strong>Estimated Annual Production:</strong> ${(quoteData.solarPotentialConfigs?.[0]?.yearlyEnergyDcKwh || quoteData.solarSizeKw * 1200).toLocaleString()} kWh</div>
        </div>

        <div class="section financial">
            <h2>Financial Summary</h2>
            <div class="quote-item"><strong>System Cost:</strong> $${(quoteData.totalCost || 0).toLocaleString()}</div>
            <div class="quote-item"><strong>BC Hydro Rebates:</strong> -$${(quoteData.totalRebates || 0).toLocaleString()}</div>
            <div class="quote-item"><strong>Net Investment:</strong> $${(quoteData.finalCost || 0).toLocaleString()}</div>
            <div class="quote-item"><strong>Estimated Annual Savings:</strong> $${(quoteData.annualSavings || 1500).toLocaleString()}</div>
            <div class="quote-item"><strong>Payback Period:</strong> ${quoteData.paybackYears || 'Calculating...'} years</div>
        </div>
    </div>

    ${proposal ? `
    <div class="section proposal">
        <h2>AI-Powered Analysis & Recommendations</h2>
        <div style="white-space: pre-line; line-height: 1.6;">${proposal.replace(/\*\*/g, '').replace(/\*/g, '')}</div>
    </div>
    ` : ''}

    <div class="footer">
        <p>BC Solar Solutions - Professional Solar Installation Services</p>
        <p>Contact us for your free consultation and site assessment</p>
    </div>
</body>
</html>`;

}