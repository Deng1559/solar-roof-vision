import { pgTable, text, serial, integer, boolean, real, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const tenants = pgTable("tenants", {
  id: serial("id").primaryKey(),
  businessName: text("business_name").notNull(),
  tagline: text("tagline"),
  phone: text("phone"),
  email: text("email"),
  address: text("address"),
  description: text("description"),
  logoUrl: text("logo_url"),
  primaryColor: text("primary_color").default("#005a87"),
  secondaryColor: text("secondary_color").default("#fdb913"),
  isActive: boolean("is_active").default(true),
});

export const solarQuotes = pgTable("solar_quotes", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id),
  customerAddress: text("customer_address").notNull(),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  solarSizeKw: real("solar_size_kw").notNull(),
  panelCount: integer("panel_count").notNull(),
  batterySize: real("battery_size").default(0),
  solarCost: real("solar_cost").notNull(),
  batteryCost: real("battery_cost").default(0),
  installationCost: real("installation_cost").notNull(),
  pstAmount: real("pst_amount").notNull(),
  totalCost: real("total_cost").notNull(),
  solarRebate: real("solar_rebate").notNull(),
  batteryRebate: real("battery_rebate").default(0),
  totalRebates: real("total_rebates").notNull(),
  finalCost: real("final_cost").notNull(),
  annualProduction: real("annual_production").notNull(),
  annualSavings: real("annual_savings").notNull(),
  paybackYears: real("payback_years").notNull(),
  roofImageUrl: text("roof_image_url"),
  solarPotentialConfigs: jsonb("solar_potential_configs"),
  aiAnalysis: text("ai_analysis"),
  aiProposal: text("ai_proposal"),
});

export const insertTenantSchema = createInsertSchema(tenants).omit({
  id: true,
});

export const insertSolarQuoteSchema = createInsertSchema(solarQuotes).omit({
  id: true,
});

export type InsertTenant = z.infer<typeof insertTenantSchema>;
export type Tenant = typeof tenants.$inferSelect;
export type InsertSolarQuote = z.infer<typeof insertSolarQuoteSchema>;
export type SolarQuote = typeof solarQuotes.$inferSelect;
